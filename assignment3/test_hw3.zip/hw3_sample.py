import yahoo_finance

def backtest (ticker = "HD", start = "2006-10-01", end = "2015-10-01", duration = 50):
    return 0.0
    
def sectortest (startdates = ["2003-01-01"], enddates =["2009-01-01"], durations =[100], file ="test2"):
    with open (file, "w") as f:
        f.write ("")

def realbacktest (ticker = "HD", start = "2006-10-01", end = "2015-10-01", duration = 50, commission = 2, file = "test3"):
    with open (file, "w") as f:
        f.write ("")
