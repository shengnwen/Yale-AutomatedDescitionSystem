library(stockPortfolio)

backtest <- function(ticker = "HD", start = "2006-10-01", end = "2015-10-01", duration = 50) {
  return (0.0)
}

sectortest <- function(startdates = list("2003-01-01"), enddates = list("2009-01-01"), durations = list(100), file ="test2") {
}

realbacktest <- function(ticker = "HD", start = "2006-10-01", end = "2015-10-01", duration = 50, commission = 2, file = "test3") {
}
