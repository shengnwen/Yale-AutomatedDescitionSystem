## CS 458/558
## Fall 2015
## author: Ronghui Gu
## email: ronghui.gu@yale.edu

# This is a sample program
import time

# read the transcript file, and return true or false
def hitme (playerhand = 12, dealerfacecard = 1):
        return True

# return a float number
def play (trials = 5):
        return 0.89

# generate the transcript file
def sim (trials = 5):
        with open("transcript", "w") as output:
                for x in xrange (0, 21):
                        for y in xrange (0, 10):
                                output.write ("0.01 ")
                        output.write ("\n")

